import { Component } from '@angular/core';

@Component({
  selector: 'app-promediosuenotodosusuario',
  imports: [],
  templateUrl: './promediosuenotodosusuario.html',
  styleUrl: './promediosuenotodosusuario.css',
})
export class Promediosuenotodosusuario {

}
