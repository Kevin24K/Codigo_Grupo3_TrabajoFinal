import { Component } from '@angular/core';

@Component({
  selector: 'app-horasdormidasporusuarioporregistro',
  imports: [],
  templateUrl: './horasdormidasporusuarioporregistro.html',
  styleUrl: './horasdormidasporusuarioporregistro.css',
})
export class Horasdormidasporusuarioporregistro {

}
