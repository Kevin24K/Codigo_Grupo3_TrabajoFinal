import { Component } from '@angular/core';

@Component({
  selector: 'app-reporte-buscar-por-umbral-calidad-suenio',
  imports: [],
  templateUrl: './reporte-buscar-por-umbral-calidad-suenio.html',
  styleUrl: './reporte-buscar-por-umbral-calidad-suenio.css',
})
export class ReporteBuscarPorUmbralCalidadSuenio {

}
