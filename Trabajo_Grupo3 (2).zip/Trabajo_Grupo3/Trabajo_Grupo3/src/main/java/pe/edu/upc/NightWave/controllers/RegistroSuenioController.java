package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.RegistroSuenioDTO;
import pe.edu.upc.NightWave.entities.RegistroSuenio;
import pe.edu.upc.NightWave.servicesinterfaces.IRegistroSuenioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/registrossuenio")
public class RegistroSuenioController {
    @Autowired
    private IRegistroSuenioService rsS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<RegistroSuenioDTO> lista = rsS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RegistroSuenioDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen registros de sueño.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody RegistroSuenioDTO dto) {
        ModelMapper m = new ModelMapper();
        RegistroSuenio rs = m.map(dto, RegistroSuenio.class);
        rsS.insert(rs);
        return ResponseEntity.ok("Registro de sueño guardado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        RegistroSuenio registro = rsS.listId(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de sueño con el ID: " + id);
        }
        rsS.delete(id);
        return ResponseEntity.ok("Registro de sueño con ID " + id + " eliminado correctamente.");
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarPorId(@PathVariable("id") Integer id) {
        RegistroSuenio registro = rsS.listId(id);
        if (registro == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro de sueño con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        RegistroSuenioDTO dto = m.map(registro, RegistroSuenioDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody RegistroSuenioDTO dto) {
        ModelMapper m = new ModelMapper();
        RegistroSuenio rs = m.map(dto, RegistroSuenio.class);
        RegistroSuenio existente = rsS.listId(rs.getIdRegistro());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro de sueño con el ID: " + rs.getIdRegistro());
        }
        rsS.update(rs);
        return ResponseEntity.ok("Registro de sueño con ID " + rs.getIdRegistro() + " modificado correctamente.");
    }
}
