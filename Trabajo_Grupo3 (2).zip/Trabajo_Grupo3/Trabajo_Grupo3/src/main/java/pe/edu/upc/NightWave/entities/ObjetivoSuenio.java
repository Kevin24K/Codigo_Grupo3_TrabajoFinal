package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "ObjetivosSuenio")
public class ObjetivoSuenio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idObjetivo;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario; // Se asume una entidad 'Usuario'

    @Column(name = "descripcion", length = 255)
    private String descripcion;

    @Column(name = "meta_horas")
    private double metaHoras;

    @Column(name = "fecha_inicio")
    private LocalDate fechaInicio;

    @Column(name = "fecha_fin")
    private LocalDate fechaFin;

    @Column(name = "cumplido")
    private boolean cumplido;

    public ObjetivoSuenio() {
    }

    public ObjetivoSuenio(int idObjetivo, Usuario usuario, String descripcion, double metaHoras, LocalDate fechaInicio, LocalDate fechaFin, boolean cumplido) {
        this.idObjetivo = idObjetivo;
        this.usuario = usuario;
        this.descripcion = descripcion;
        this.metaHoras = metaHoras;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.cumplido = cumplido;
    }

    public int getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(int idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getMetaHoras() {
        return metaHoras;
    }

    public void setMetaHoras(double metaHoras) {
        this.metaHoras = metaHoras;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isCumplido() {
        return cumplido;
    }

    public void setCumplido(boolean cumplido) {
        this.cumplido = cumplido;
    }
}
