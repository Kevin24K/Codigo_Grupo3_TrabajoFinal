package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalTime;

@Entity
@Table(name = "Recordatorios")
public class Recordatorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRecordatorio;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario; // Se asume una entidad 'Usuario'

    @Column(name = "tipo", length = 20, nullable = false)
    private String tipo;

    @Column(name = "mensaje", length = 255)
    private String mensaje;

    @Column(name = "hora_programada")
    private LocalTime horaProgramada;

    @Column(name = "activo")
    private boolean activo;

    public Recordatorio() {
    }

    public Recordatorio(int idRecordatorio, Usuario usuario, String tipo, String mensaje, LocalTime horaProgramada, boolean activo) {
        this.idRecordatorio = idRecordatorio;
        this.usuario = usuario;
        this.tipo = tipo;
        this.mensaje = mensaje;
        this.horaProgramada = horaProgramada;
        this.activo = activo;
    }

    public int getIdRecordatorio() {
        return idRecordatorio;
    }

    public void setIdRecordatorio(int idRecordatorio) {
        this.idRecordatorio = idRecordatorio;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public LocalTime getHoraProgramada() {
        return horaProgramada;
    }

    public void setHoraProgramada(LocalTime horaProgramada) {
        this.horaProgramada = horaProgramada;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
