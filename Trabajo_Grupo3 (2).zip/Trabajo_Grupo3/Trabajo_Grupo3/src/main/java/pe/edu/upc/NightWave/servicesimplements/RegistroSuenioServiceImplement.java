package pe.edu.upc.NightWave.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.NightWave.entities.RegistroSuenio;
import pe.edu.upc.NightWave.repositories.IRegistroSuenioRepository;
import pe.edu.upc.NightWave.servicesinterfaces.IRegistroSuenioService;

import java.util.List;

@Service
public class RegistroSuenioServiceImplement implements IRegistroSuenioService {

    @Autowired
    private IRegistroSuenioRepository rsR;

    @Override
    public void insert(RegistroSuenio registroSuenio) {
        rsR.save(registroSuenio);
    }

    @Override
    public List<RegistroSuenio> list() {
        return rsR.findAll();
    }

    @Override
    public void delete(int id) {
        rsR.deleteById(id);
    }

    @Override
    public RegistroSuenio listId(int id) {
        return rsR.findById(id).orElse(null);
    }

    @Override
    public void update(RegistroSuenio registroSuenio) {
        rsR.save(registroSuenio);
    }
}
