package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.PerfilSuenioDTO;
import pe.edu.upc.NightWave.entities.PerfilSuenio;
import pe.edu.upc.NightWave.servicesinterfaces.IPerfilSuenioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/perfilessuenio")
public class PerfilSuenioController {

    @Autowired
    private IPerfilSuenioService psS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<PerfilSuenioDTO> lista = psS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, PerfilSuenioDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen perfiles de sueño registrados.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody PerfilSuenioDTO dto) {
        ModelMapper m = new ModelMapper();
        PerfilSuenio ps = m.map(dto, PerfilSuenio.class);
        psS.insert(ps);
        return ResponseEntity.ok("Perfil de sueño registrado correctamente.");
    }
}
