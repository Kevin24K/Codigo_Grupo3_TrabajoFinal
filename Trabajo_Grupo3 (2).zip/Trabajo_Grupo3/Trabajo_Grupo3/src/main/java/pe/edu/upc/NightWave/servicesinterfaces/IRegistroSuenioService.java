package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.RegistroSuenio;

import java.util.List;

public interface IRegistroSuenioService {
    public void insert(RegistroSuenio registroSuenio);
    public List<RegistroSuenio> list();
    public void delete(int id);
    public RegistroSuenio listId(int id);
    public void update(RegistroSuenio registroSuenio);
}
