package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.PerfilSuenio;

import java.util.List;

public interface IPerfilSuenioService {
    public void insert(PerfilSuenio perfilSuenio);
    public List<PerfilSuenio> list();
}
