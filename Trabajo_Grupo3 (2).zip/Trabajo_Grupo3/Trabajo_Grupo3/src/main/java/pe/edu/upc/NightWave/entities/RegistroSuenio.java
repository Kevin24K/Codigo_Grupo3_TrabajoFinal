package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "RegistrosSuenio")
public class RegistroSuenio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRegistro;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro;

    @Column(name = "hora_inicio")
    private LocalDateTime horaInicio;

    @Column(name = "hora_fin")
    private LocalDateTime horaFin;

    @Column(name = "duracion_horas")
    private double duracionHoras;

    @Column(name = "calidad_sueno", length = 50)
    private int calidadSueno;

    @Column(name = "cantidad_despertares_nocturnos")
    private int cantidadDespertaresNocturnos;

    @ManyToOne
    @JoinColumn(name = "id_integracion")
    private Integracion integracion;

    public RegistroSuenio() {
    }

    public RegistroSuenio(int idRegistro, Usuario usuario, LocalDate fechaRegistro, LocalDateTime horaInicio, LocalDateTime horaFin, double duracionHoras, int calidadSueno, int cantidadDespertaresNocturnos, Integracion integracion) {
        this.idRegistro = idRegistro;
        this.usuario = usuario;
        this.fechaRegistro = fechaRegistro;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.duracionHoras = duracionHoras;
        this.calidadSueno = calidadSueno;
        this.cantidadDespertaresNocturnos = cantidadDespertaresNocturnos;
        this.integracion = integracion;
    }

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public LocalDateTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalDateTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalDateTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalDateTime horaFin) {
        this.horaFin = horaFin;
    }

    public double getDuracionHoras() {
        return duracionHoras;
    }

    public void setDuracionHoras(double duracionHoras) {
        this.duracionHoras = duracionHoras;
    }

    public int getCalidadSueno() {
        return calidadSueno;
    }

    public void setCalidadSueno(int calidadSueno) {
        this.calidadSueno = calidadSueno;
    }

    public int getCantidadDespertaresNocturnos() {
        return cantidadDespertaresNocturnos;
    }

    public void setCantidadDespertaresNocturnos(int cantidadDespertaresNocturnos) {
        this.cantidadDespertaresNocturnos = cantidadDespertaresNocturnos;
    }

    public Integracion getIntegracion() {
        return integracion;
    }

    public void setIntegracion(Integracion integracion) {
        this.integracion = integracion;
    }
}
