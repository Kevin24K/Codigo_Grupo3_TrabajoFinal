package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "Recompensas")
public class Recompensa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRecompensa;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario; // Se asume una entidad 'Usuario'

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "fecha_obtenido", nullable = false)
    private LocalDateTime fechaObtenido;

    @Column(name = "puntos",  nullable = false)
    private int puntos;

    public Recompensa() {
    }

    public Recompensa(int idRecompensa, Usuario usuario, String descripcion, LocalDateTime fechaObtenido, int puntos) {
        this.idRecompensa = idRecompensa;
        this.usuario = usuario;
        this.descripcion = descripcion;
        this.fechaObtenido = fechaObtenido;
        this.puntos = puntos;
    }

    public int getIdRecompensa() {
        return idRecompensa;
    }

    public void setIdRecompensa(int idRecompensa) {
        this.idRecompensa = idRecompensa;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDateTime getFechaObtenido() {
        return fechaObtenido;
    }

    public void setFechaObtenido(LocalDateTime fechaObtenido) {
        this.fechaObtenido = fechaObtenido;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}
