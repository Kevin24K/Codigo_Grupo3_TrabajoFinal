package pe.edu.upc.NightWave.dtos;

import pe.edu.upc.NightWave.entities.Usuario;

import java.time.LocalDateTime;

public class RecompensaDTO {
    private int idRecompensa;
    private Usuario usuario;
    private String descripcion;
    private LocalDateTime fechaObtenido;
    private int puntos;

    public int getIdRecompensa() {
        return idRecompensa;
    }

    public void setIdRecompensa(int idRecompensa) {
        this.idRecompensa = idRecompensa;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDateTime getFechaObtenido() {
        return fechaObtenido;
    }

    public void setFechaObtenido(LocalDateTime fechaObtenido) {
        this.fechaObtenido = fechaObtenido;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}
