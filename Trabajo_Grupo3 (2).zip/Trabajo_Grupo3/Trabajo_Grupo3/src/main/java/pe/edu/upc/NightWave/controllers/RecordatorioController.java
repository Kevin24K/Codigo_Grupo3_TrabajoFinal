package pe.edu.upc.NightWave.controllers;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.RecordatorioDTO;
import pe.edu.upc.NightWave.entities.Recordatorio;
import pe.edu.upc.NightWave.servicesinterfaces.IRecordatorioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/recordatorios")
public class RecordatorioController {
    @Autowired
    private IRecordatorioService rS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<RecordatorioDTO> lista = rS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RecordatorioDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen recordatorios registrados.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody RecordatorioDTO dto) {
        ModelMapper m = new ModelMapper();
        Recordatorio re = m.map(dto, Recordatorio.class);
        rS.insert(re);
        return ResponseEntity.ok("Recordatorio registrado correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Recordatorio recordatorio = rS.listId(id);
        if (recordatorio == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        rS.delete(id);
        return ResponseEntity.ok("Registro con ID " + id + " eliminado correctamente.");
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Recordatorio recordatorio = rS.listId(id);
        if (recordatorio == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe un registro con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        RecordatorioDTO dto = m.map(recordatorio, RecordatorioDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody RecordatorioDTO dto) {
        ModelMapper m = new ModelMapper();
        Recordatorio r = m.map(dto, Recordatorio.class);

        Recordatorio existente = rS.listId(r.getIdRecordatorio());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + r.getIdRecordatorio());
        }
        rS.update(r);
        return ResponseEntity.ok("Registro con ID " + r.getIdRecordatorio() + " modificado correctamente.");
    }
}
