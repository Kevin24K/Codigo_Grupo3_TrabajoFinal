package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "PerfilesSuenio")
public class PerfilSuenio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPerfil;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @Column(name = "horas_promedio")
    private double horasPromedio;

    @Column(name = "nivel_estres")
    private int nivelEstres;

    @Column(name = "cafeina_noche")
    private boolean cafeinaNoche;

    @Column(name = "actividad_fisica")
    private boolean actividadFisica;

    @Column(name = "necesidades")
    private String necesidades;

    @Column(name = "metodos_favoritos")
    private String metodosFavoritos;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    public PerfilSuenio() {
    }

    public PerfilSuenio(int idPerfil, Usuario usuario, double horasPromedio, int nivelEstres, boolean cafeinaNoche, boolean actividadFisica, String necesidades, String metodosFavoritos, LocalDateTime fechaCreacion) {
        this.idPerfil = idPerfil;
        this.usuario = usuario;
        this.horasPromedio = horasPromedio;
        this.nivelEstres = nivelEstres;
        this.cafeinaNoche = cafeinaNoche;
        this.actividadFisica = actividadFisica;
        this.necesidades = necesidades;
        this.metodosFavoritos = metodosFavoritos;
        this.fechaCreacion = fechaCreacion;
    }

    public int getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil) {
        this.idPerfil = idPerfil;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public double getHorasPromedio() {
        return horasPromedio;
    }

    public void setHorasPromedio(double horasPromedio) {
        this.horasPromedio = horasPromedio;
    }

    public int getNivelEstres() {
        return nivelEstres;
    }

    public void setNivelEstres(int nivelEstres) {
        this.nivelEstres = nivelEstres;
    }

    public boolean isCafeinaNoche() {
        return cafeinaNoche;
    }

    public void setCafeinaNoche(boolean cafeinaNoche) {
        this.cafeinaNoche = cafeinaNoche;
    }

    public boolean isActividadFisica() {
        return actividadFisica;
    }

    public void setActividadFisica(boolean actividadFisica) {
        this.actividadFisica = actividadFisica;
    }

    public String getNecesidades() {
        return necesidades;
    }

    public void setNecesidades(String necesidades) {
        this.necesidades = necesidades;
    }

    public String getMetodosFavoritos() {
        return metodosFavoritos;
    }

    public void setMetodosFavoritos(String metodosFavoritos) {
        this.metodosFavoritos = metodosFavoritos;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
