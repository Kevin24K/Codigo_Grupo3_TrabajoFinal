package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.MeditacionDTO;
import pe.edu.upc.NightWave.entities.Meditacion;
import pe.edu.upc.NightWave.servicesinterfaces.IMeditacionService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/meditaciones")
public class MeditacionController {

    @Autowired
    private IMeditacionService mS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<MeditacionDTO> lista = mS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, MeditacionDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen meditaciones registradas.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody MeditacionDTO dto) {
        ModelMapper m = new ModelMapper();
        Meditacion me = m.map(dto, Meditacion.class);
        mS.insert(me);
        return ResponseEntity.ok("Meditación registrada correctamente.");
    }
}
