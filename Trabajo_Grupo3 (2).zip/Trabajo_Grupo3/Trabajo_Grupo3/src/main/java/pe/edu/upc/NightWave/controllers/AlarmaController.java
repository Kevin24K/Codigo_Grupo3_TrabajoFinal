package pe.edu.upc.NightWave.controllers;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.AlarmaDTO;
import pe.edu.upc.NightWave.entities.Alarma;
import pe.edu.upc.NightWave.servicesinterfaces.IAlarmaService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/alarmas")
public class AlarmaController {
    @Autowired
    private IAlarmaService aS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<AlarmaDTO> lista = aS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, AlarmaDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen alarmas registradas.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody AlarmaDTO dto) {
        ModelMapper m = new ModelMapper();
        Alarma al = m.map(dto, Alarma.class);
        aS.insert(al);
        return ResponseEntity.ok("Alarma registrada correctamente.");
    }
}
