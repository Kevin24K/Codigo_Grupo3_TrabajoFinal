package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.HistorialAccesoDTO;
import pe.edu.upc.NightWave.entities.HistorialAcceso;
import pe.edu.upc.NightWave.servicesinterfaces.IHistorialAccesoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/historialacceso")
public class HistorialAccesoController {
    @Autowired
    private IHistorialAccesoService haS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<HistorialAccesoDTO> lista = haS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, HistorialAccesoDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen registros de historial de acceso.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody HistorialAccesoDTO dto) {
        ModelMapper m = new ModelMapper();
        HistorialAcceso ha = m.map(dto, HistorialAcceso.class);
        haS.insert(ha);
        return ResponseEntity.ok("Registro de historial de acceso guardado correctamente.");
    }
}
