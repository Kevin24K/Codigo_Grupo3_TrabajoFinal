package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.HistorialAcceso;

import java.util.List;

public interface IHistorialAccesoService {
    public void insert(HistorialAcceso historialAcceso);
    public List<HistorialAcceso> list();
}
