package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.Recordatorio;

import java.util.List;

public interface IRecordatorioService {
    public void insert(Recordatorio recordatorio);
    public List<Recordatorio> list();
    public void delete(int id);
    public Recordatorio listId(int id);
    public void update(Recordatorio recordatorio);
}
