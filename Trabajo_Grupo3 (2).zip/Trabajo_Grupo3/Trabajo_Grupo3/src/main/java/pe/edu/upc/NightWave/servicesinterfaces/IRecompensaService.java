package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.Recompensa;

import java.util.List;

public interface IRecompensaService {
    public void insert(Recompensa recompensa);
    public List<Recompensa> list();
    public void delete(int id);
    public Recompensa listId(int id);
    public void update(Recompensa recompensa);
}
