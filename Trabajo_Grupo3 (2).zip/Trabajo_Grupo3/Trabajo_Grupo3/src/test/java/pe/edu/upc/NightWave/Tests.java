package pe.edu.upc.NightWave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NightWaveApplicationTests {

    @Test
    void contextLoads() {
    }

}
