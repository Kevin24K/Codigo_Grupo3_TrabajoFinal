package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.RegistroSuenioDTO;
import pe.edu.upc.NightWave.entities.RegistroSuenio;
import pe.edu.upc.NightWave.servicesinterfaces.IRegistroSuenioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/registrossuenio")
public class RegistroSuenioController {
    @Autowired
    private IRegistroSuenioService rsS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<RegistroSuenioDTO> lista = rsS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, RegistroSuenioDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen registros de sueño.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody RegistroSuenioDTO dto) {
        ModelMapper m = new ModelMapper();
        RegistroSuenio rs = m.map(dto, RegistroSuenio.class);
        rsS.insert(rs);
        return ResponseEntity.ok("Registro de sueño guardado correctamente.");
    }
}
