package pe.edu.upc.NightWave.dtos;

import pe.edu.upc.NightWave.entities.Usuario;

import java.time.LocalDateTime;

public class PerfilSuenioDTO {
    private int idPerfil;
    private Usuario usuario;
    private double horasPromedio;
    private int nivelEstres;
    private boolean cafeinaNoche;
    private boolean actividadFisica;
    private String necesidades;
    private String metodosFavoritos;
    private LocalDateTime fechaCreacion;

    public int getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil) {
        this.idPerfil = idPerfil;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public double getHorasPromedio() {
        return horasPromedio;
    }

    public void setHorasPromedio(double horasPromedio) {
        this.horasPromedio = horasPromedio;
    }

    public int getNivelEstres() {
        return nivelEstres;
    }

    public void setNivelEstres(int nivelEstres) {
        this.nivelEstres = nivelEstres;
    }

    public boolean isCafeinaNoche() {
        return cafeinaNoche;
    }

    public void setCafeinaNoche(boolean cafeinaNoche) {
        this.cafeinaNoche = cafeinaNoche;
    }

    public boolean isActividadFisica() {
        return actividadFisica;
    }

    public void setActividadFisica(boolean actividadFisica) {
        this.actividadFisica = actividadFisica;
    }

    public String getNecesidades() {
        return necesidades;
    }

    public void setNecesidades(String necesidades) {
        this.necesidades = necesidades;
    }

    public String getMetodosFavoritos() {
        return metodosFavoritos;
    }

    public void setMetodosFavoritos(String metodosFavoritos) {
        this.metodosFavoritos = metodosFavoritos;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
