package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.ObjetivoSuenio;

import java.util.List;

public interface IObjetivoSuenioService {
    public void insert(ObjetivoSuenio objetivoSuenio);
    public List<ObjetivoSuenio> list();
}
