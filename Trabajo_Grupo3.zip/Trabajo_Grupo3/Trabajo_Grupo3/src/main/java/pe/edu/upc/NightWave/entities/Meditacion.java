package pe.edu.upc.NightWave.entities;


import jakarta.persistence.*;

@Entity
@Table(name = "Meditaciones")
public class Meditacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idMeditacion;

    @Column(name = "titulo", length = 100, nullable = false)
    private String titulo;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "duracion")
    private int duracion; // minutos

    @Column(name = "nivel_dificultad", length = 10)
    private String nivelDificultad;

    @ManyToOne
    @JoinColumn(name = "id_sonido")
    private Sonido sonido; // Se asume una entidad 'Sonido'

    @Column(name = "categoria", length = 20)
    private String categoria;

    public Meditacion() {
    }

    public Meditacion(int idMeditacion, String titulo, String descripcion, int duracion, String nivelDificultad, Sonido sonido, String categoria) {
        this.idMeditacion = idMeditacion;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.nivelDificultad = nivelDificultad;
        this.sonido = sonido;
        this.categoria = categoria;
    }

    public int getIdMeditacion() {
        return idMeditacion;
    }

    public void setIdMeditacion(int idMeditacion) {
        this.idMeditacion = idMeditacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getNivelDificultad() {
        return nivelDificultad;
    }

    public void setNivelDificultad(String nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    public Sonido getSonido() {
        return sonido;
    }

    public void setSonido(Sonido sonido) {
        this.sonido = sonido;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
