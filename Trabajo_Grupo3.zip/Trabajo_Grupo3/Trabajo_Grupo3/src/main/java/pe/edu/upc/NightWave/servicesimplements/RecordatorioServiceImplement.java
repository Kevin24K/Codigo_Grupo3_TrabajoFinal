package pe.edu.upc.NightWave.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.NightWave.entities.Recordatorio;
import pe.edu.upc.NightWave.repositories.IRecordatorioRepository;
import pe.edu.upc.NightWave.servicesinterfaces.IRecordatorioService;

import java.util.List;

@Service
public class RecordatorioServiceImplement implements IRecordatorioService {

    @Autowired
    private IRecordatorioRepository rR;

    @Override
    public void insert(Recordatorio recordatorio) {
        rR.save(recordatorio);
    }

    @Override
    public List<Recordatorio> list() {
        return rR.findAll();
    }
}
