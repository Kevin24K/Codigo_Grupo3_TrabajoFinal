package pe.edu.upc.NightWave.servicesinterfaces;

import pe.edu.upc.NightWave.entities.Meditacion;

import java.util.List;

public interface IMeditacionService {
    public void insert(Meditacion meditacion);
    public List<Meditacion> list();
}
