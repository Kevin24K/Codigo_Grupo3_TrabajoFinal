package pe.edu.upc.NightWave.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.NightWave.entities.ObjetivoSuenio;
import pe.edu.upc.NightWave.repositories.IObjetivoSuenioRepository;
import pe.edu.upc.NightWave.servicesinterfaces.IObjetivoSuenioService;

import java.util.List;

@Service
public class ObjetivoSuenioServiceImplement implements IObjetivoSuenioService {

    @Autowired
    private IObjetivoSuenioRepository osR;

    @Override
    public void insert(ObjetivoSuenio objetivoSuenio) {
        osR.save(objetivoSuenio);
    }

    @Override
    public List<ObjetivoSuenio> list() {
        return osR.findAll();
    }
}
