package pe.edu.upc.NightWave.dtos;

import pe.edu.upc.NightWave.entities.Integracion;
import pe.edu.upc.NightWave.entities.Usuario;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class RegistroSuenioDTO {
    private int idRegistro;
    private Usuario usuario;
    private LocalDate fechaRegistro;
    private LocalDateTime horaInicio;
    private LocalDateTime horaFin;
    private double duracionHoras;
    private int calidadSueno;
    private int cantidadDespertaresNocturnos;
    private Integracion integracion;

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public LocalDateTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalDateTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalDateTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalDateTime horaFin) {
        this.horaFin = horaFin;
    }

    public double getDuracionHoras() {
        return duracionHoras;
    }

    public void setDuracionHoras(double duracionHoras) {
        this.duracionHoras = duracionHoras;
    }

    public int getCalidadSueno() {
        return calidadSueno;
    }

    public void setCalidadSueno(int calidadSueno) {
        this.calidadSueno = calidadSueno;
    }

    public int getCantidadDespertaresNocturnos() {
        return cantidadDespertaresNocturnos;
    }

    public void setCantidadDespertaresNocturnos(int cantidadDespertaresNocturnos) {
        this.cantidadDespertaresNocturnos = cantidadDespertaresNocturnos;
    }

    public Integracion getIntegracion() {
        return integracion;
    }

    public void setIntegracion(Integracion integracion) {
        this.integracion = integracion;
    }
}
