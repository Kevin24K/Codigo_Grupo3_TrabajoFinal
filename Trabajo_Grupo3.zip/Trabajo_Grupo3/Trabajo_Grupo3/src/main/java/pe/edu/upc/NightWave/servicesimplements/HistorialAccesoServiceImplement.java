package pe.edu.upc.NightWave.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.NightWave.entities.HistorialAcceso;
import pe.edu.upc.NightWave.repositories.IHistorialAccesoRepository;
import pe.edu.upc.NightWave.servicesinterfaces.IHistorialAccesoService;

import java.util.List;

@Service
public class HistorialAccesoServiceImplement implements IHistorialAccesoService {

    @Autowired
    private IHistorialAccesoRepository haR;

    @Override
    public void insert(HistorialAcceso historialAcceso) {
        haR.save(historialAcceso);
    }

    @Override
    public List<HistorialAcceso> list() {
        return haR.findAll();
    }
}
