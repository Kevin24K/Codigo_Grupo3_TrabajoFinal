package pe.edu.upc.NightWave.entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "Integraciones")
public class Integracion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idIntegracion;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @Column(name = "dispositivo", length = 100)
    private String dispositivo;

    @Column(name = "tipo", length = 20)
    private String tipo;

    @Column(name = "estado", nullable = false)
    private boolean estado;

    @Column(name = "fecha_sincronizacion")
    private LocalDate fechaSincronizacion;

    public Integracion() {
    }

    public Integracion(int idIntegracion, Usuario usuario, String dispositivo, String tipo, boolean estado, LocalDate fechaSincronizacion) {
        this.idIntegracion = idIntegracion;
        this.usuario = usuario;
        this.dispositivo = dispositivo;
        this.tipo = tipo;
        this.estado = estado;
        this.fechaSincronizacion = fechaSincronizacion;
    }

    public int getIdIntegracion() {
        return idIntegracion;
    }

    public void setIdIntegracion(int idIntegracion) {
        this.idIntegracion = idIntegracion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDispositivo() {
        return dispositivo;
    }

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public LocalDate getFechaSincronizacion() {
        return fechaSincronizacion;
    }

    public void setFechaSincronizacion(LocalDate fechaSincronizacion) {
        this.fechaSincronizacion = fechaSincronizacion;
    }
}
