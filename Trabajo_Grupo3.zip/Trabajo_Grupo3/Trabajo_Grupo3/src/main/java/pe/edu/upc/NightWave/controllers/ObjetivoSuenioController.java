package pe.edu.upc.NightWave.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.NightWave.dtos.ObjetivoSuenioDTO;
import pe.edu.upc.NightWave.entities.ObjetivoSuenio;
import pe.edu.upc.NightWave.servicesinterfaces.IObjetivoSuenioService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/objetivossuenio")
public class ObjetivoSuenioController {

    @Autowired
    private IObjetivoSuenioService osS;

    @GetMapping
    public ResponseEntity<?> listar() {
        List<ObjetivoSuenioDTO> lista = osS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ObjetivoSuenioDTO.class);
        }).collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body("No existen objetivos de sueño registrados.");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody ObjetivoSuenioDTO dto) {
        ModelMapper m = new ModelMapper();
        ObjetivoSuenio os = m.map(dto, ObjetivoSuenio.class);
        osS.insert(os);
        return ResponseEntity.ok("Objetivo de sueño registrado correctamente.");
    }
}
