package pe.edu.upc.NightWave.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.NightWave.entities.PerfilSuenio;
import pe.edu.upc.NightWave.repositories.IPerfilSuenioRepository;
import pe.edu.upc.NightWave.servicesinterfaces.IPerfilSuenioService;

import java.util.List;

@Service
public class PerfilSuenioServiceImplement implements IPerfilSuenioService {

    @Autowired
    private IPerfilSuenioRepository psR;

    @Override
    public void insert(PerfilSuenio perfilSuenio) {
        psR.save(perfilSuenio);
    }

    @Override
    public List<PerfilSuenio> list() {
        return psR.findAll();
    }
}
