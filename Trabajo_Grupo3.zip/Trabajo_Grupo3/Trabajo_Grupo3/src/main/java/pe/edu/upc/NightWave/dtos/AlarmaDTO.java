package pe.edu.upc.NightWave.dtos;

import pe.edu.upc.NightWave.entities.Sonido;
import pe.edu.upc.NightWave.entities.Usuario;

import java.time.LocalTime;

public class AlarmaDTO {
    private int idAlarma;
    private Usuario usuario;
    private LocalTime horaAlarma;
    private Sonido sonido;
    private String diasActivos;
    private boolean activa;

    public int getIdAlarma() {
        return idAlarma;
    }

    public void setIdAlarma(int idAlarma) {
        this.idAlarma = idAlarma;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalTime getHoraAlarma() {
        return horaAlarma;
    }

    public void setHoraAlarma(LocalTime horaAlarma) {
        this.horaAlarma = horaAlarma;
    }

    public Sonido getSonido() {
        return sonido;
    }

    public void setSonido(Sonido sonido) {
        this.sonido = sonido;
    }

    public String getDiasActivos() {
        return diasActivos;
    }

    public void setDiasActivos(String diasActivos) {
        this.diasActivos = diasActivos;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }
}
