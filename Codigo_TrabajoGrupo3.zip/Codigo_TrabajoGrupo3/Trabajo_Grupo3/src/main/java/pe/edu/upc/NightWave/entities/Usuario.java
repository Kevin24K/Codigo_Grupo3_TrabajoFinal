package pe.edu.upc.NightWave.entities;

import jakarta.persistence.Entity;

@Entity
public class Usuario {
}