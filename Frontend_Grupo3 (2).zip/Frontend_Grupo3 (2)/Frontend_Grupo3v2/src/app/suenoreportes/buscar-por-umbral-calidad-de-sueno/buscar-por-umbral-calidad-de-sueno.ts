import { Component } from '@angular/core';

@Component({
  selector: 'app-buscar-por-umbral-calidad-de-sueno',
  imports: [],
  templateUrl: './buscar-por-umbral-calidad-de-sueno.html',
  styleUrl: './buscar-por-umbral-calidad-de-sueno.css',
})
export class BuscarPorUmbralCalidadDeSueno {

}
