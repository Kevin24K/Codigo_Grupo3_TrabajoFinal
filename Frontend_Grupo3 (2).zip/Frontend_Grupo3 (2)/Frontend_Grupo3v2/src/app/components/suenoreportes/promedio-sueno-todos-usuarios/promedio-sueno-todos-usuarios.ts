import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { PromedioSuenoDTO } from '../../../models/PromedioSuenoDTO';
import { SuenoService } from '../../../services/sueno-service';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-promedio-sueno-todos-usuarios',
  imports: [CommonModule,
    MatTableModule,
    MatIconModule],
  templateUrl: './promedio-sueno-todos-usuarios.html',
  styleUrl: './promedio-sueno-todos-usuarios.css',
})
export class PromedioSuenoTodosUsuarios implements OnInit{
  displayedColumns: string[] = [
    'idUsuario',
    'promedioHorasDormidas',
    'promedioInterrupciones',
    'promedioCalidad',
  ];

  dataSource: MatTableDataSource<PromedioSuenoDTO> = new MatTableDataSource();

  constructor(private sService: SuenoService) {}

  ngOnInit(): void {
    // Llamada al Query
    this.sService.promedioSuenoTodosUsuarios().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
    });
  }
}
