package servicesinterfaces;

import entities.Usuario;
import java.util.List;

public interface IUsuarioService {
    public void insert(Usuario usuario);
    public List<Usuario> list();
    public void delete(int id);
    public Usuario listId(int id);
}
