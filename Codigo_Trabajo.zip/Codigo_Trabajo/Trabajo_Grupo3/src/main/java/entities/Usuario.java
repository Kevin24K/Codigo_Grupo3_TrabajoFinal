package entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Table(name = "Usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_usuario;
    @Column(name = "nombre_completo", nullable = false, length = 100)
    private String nombre_completo;
    @Column(name = "correo_electronico", nullable = false, unique = true, length = 100)
    private String correo_electronico;
    @Column(name = "contrasenia", nullable = false, length = 255)
    private String contrasenia;
    @Column(name = "fecha_nacimiento")
    private LocalDate fecha_nacimiento;
    @Column(name = "departamento", length = 50)
    private String departamento;
    @Column(name = "distrito", length = 50)
    private String distrito;
    @Column(name = "telefono", length = 20)
    private String telefono;
    @Column(name = "fecha_registro")
    private LocalDateTime fecha_registro;
    @Column(name = "ultimo_acceso")
    private LocalDateTime ultimo_acceso;

    public Usuario() {
    }

    public Usuario(int id_usuario, String nombre_completo, String correo_electronico, String contrasenia, LocalDate fecha_nacimiento, String departamento, String distrito, String telefono, LocalDateTime fecha_registro, LocalDateTime ultimo_acceso) {
        this.id_usuario = id_usuario;
        this.nombre_completo = nombre_completo;
        this.correo_electronico = correo_electronico;
        this.contrasenia = contrasenia;
        this.fecha_nacimiento = fecha_nacimiento;
        this.departamento = departamento;
        this.distrito = distrito;
        this.telefono = telefono;
        this.fecha_registro = fecha_registro;
        this.ultimo_acceso = ultimo_acceso;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre_completo() {
        return nombre_completo;
    }

    public void setNombre_completo(String nombre_completo) {
        this.nombre_completo = nombre_completo;
    }

    public String getCorreo_electronico() {
        return correo_electronico;
    }

    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public LocalDate getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(LocalDate fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public LocalDateTime getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(LocalDateTime fecha_registro) {
        this.fecha_registro = fecha_registro;
    }

    public LocalDateTime getUltimo_acceso() {
        return ultimo_acceso;
    }

    public void setUltimo_acceso(LocalDateTime ultimo_acceso) {
        this.ultimo_acceso = ultimo_acceso;
    }
}
